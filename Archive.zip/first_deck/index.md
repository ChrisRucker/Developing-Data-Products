---
title       : 2014-15 NBA REGULAR SEASON LEADERS
subtitle    : Official League Leaders
author      : Chris Rucker, Senior Database Analyst
job         : Mediacom Communications Corporation
framework   : io2012        # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : []            # {mathjax, quiz, bootstrap}
mode        : selfcontained # {standalone, draft}
knit        : slidify::knit2slides
---

## Histogram

A histogram is a graphical representation of a quantitative variable. This histogram shows how points are distributed amongst two-hundred seventy-seven scoring leaders in the National Basketball Association for the 2014-15 regular season.

---

## Operation

Move the slider to change the number of players viewed in the histogram from one to two-hundred seventy-seven scoring leaders.

---

## Axes

Points on the x-axis of the histogram represent the number of points a player has scored. A point is scored when a player makes a basket. Frequency on the y-axis of the histogram represents the number of occurrences of a repeating event per unit time.

---

## Skewness and Mean

The histogram is skewed to the right because the mass of the distribution is concentrated on the left of the figure also known as a positive skew. The measure of central tendency is a central or typical value for a probability distribution and is represented by the red line in the histogram also known as the mean. Note that the mean is for the entire dataset and does not move in this instance.

---
